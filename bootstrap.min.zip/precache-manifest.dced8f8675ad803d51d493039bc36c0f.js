self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "da7eb756d87cc22d3e4683869e1254c6",
    "url": "/unica-new/react/index.html"
  },
  {
    "revision": "7548b92462a8f88c29a2",
    "url": "/unica-new/react/static/css/main.f53393b4.chunk.css"
  },
  {
    "revision": "433468cb7f1fd8af5a5e",
    "url": "/unica-new/react/static/js/2.30692906.chunk.js"
  },
  {
    "revision": "7548b92462a8f88c29a2",
    "url": "/unica-new/react/static/js/main.19e10773.chunk.js"
  },
  {
    "revision": "af95189c7a844c4967ca",
    "url": "/unica-new/react/static/js/runtime~main.f051b1b8.js"
  },
  {
    "revision": "d0245cd5d320780a73553bab0bc222c7",
    "url": "/unica-new/react/static/media/b2b-networking.d0245cd5.png"
  },
  {
    "revision": "fb46c4e78d2db6f778ccf048fd33b615",
    "url": "/unica-new/react/static/media/banner.fb46c4e7.jpg"
  },
  {
    "revision": "ec68cbdcb9af2f9a40765986c2b2567a",
    "url": "/unica-new/react/static/media/dedicated-campaign.ec68cbdc.png"
  },
  {
    "revision": "023ba0824a99109c4a63622228dd6354",
    "url": "/unica-new/react/static/media/feather.023ba082.svg"
  },
  {
    "revision": "5fad700adc948cb51404d55833347f51",
    "url": "/unica-new/react/static/media/feather.5fad700a.eot"
  },
  {
    "revision": "66cbb621b431bf32041a5c478e5539c0",
    "url": "/unica-new/react/static/media/feather.66cbb621.woff"
  },
  {
    "revision": "a940fe89dbfe9d1d89fc1aa0488fe032",
    "url": "/unica-new/react/static/media/feather.a940fe89.ttf"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/unica-new/react/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "acf3dcb7ff752b5296ca23ba2c7c2606",
    "url": "/unica-new/react/static/media/fontawesome-webfont.acf3dcb7.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/unica-new/react/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/unica-new/react/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/unica-new/react/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "f3b8d2face41b357042b0e7fe4352a4a",
    "url": "/unica-new/react/static/media/high-cost.f3b8d2fa.png"
  },
  {
    "revision": "e1d4de9a2eb2c1a2bb1ec1a0bef1ceee",
    "url": "/unica-new/react/static/media/incomplete-information.e1d4de9a.png"
  },
  {
    "revision": "9737f2043d1285e76722f72a02c94be9",
    "url": "/unica-new/react/static/media/no-assurance-of-results.9737f204.png"
  },
  {
    "revision": "47dbe0475e242dad2098c66da9441495",
    "url": "/unica-new/react/static/media/poor-conversion-rate.47dbe047.png"
  },
  {
    "revision": "d3cb66839aa56e89dddb080f42d799a2",
    "url": "/unica-new/react/static/media/solved.d3cb6683.png"
  },
  {
    "revision": "433146defaba32b689a7ea27eef57a3d",
    "url": "/unica-new/react/static/media/student-fairs.433146de.png"
  },
  {
    "revision": "7cb5b9eff77c473b84796050baaf7673",
    "url": "/unica-new/react/static/media/unica-proposal.7cb5b9ef.pdf"
  },
  {
    "revision": "4dcc1b6a216791e67307df0b53932334",
    "url": "/unica-new/react/static/media/unica-screen.4dcc1b6a.png"
  },
  {
    "revision": "853d83214706c312f8c5489d48021292",
    "url": "/unica-new/react/static/media/upfront-investment.853d8321.png"
  }
]);